import React, { useState } from 'react';
import { X, Smartphone, Download, Copy, Check, Terminal, ExternalLink, ShieldCheck } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install, isAndroid } = usePWAInstall();
  const [copiedFlutter, setCopiedFlutter] = useState(false);
  const [copiedCli, setCopiedCli] = useState(false);
  const [activeTab, setActiveTab] = useState<'direct' | 'flutter' | 'twa'>('direct');

  if (!isOpen) return null;

  const flutterSourceCode = `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const InvokersynyApp());

class InvokersynyApp extends StatelessWidget {
  const InvokersynyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'INVOKERSYNY PROMPT BUILDER',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0E1013),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF16181D),
          elevation: 2,
        ),
      ),
      home: const PromptGenerator(),
    );
  }
}

class PromptGenerator extends StatefulWidget {
  const PromptGenerator({super.key});

  @override
  State<PromptGenerator> createState() => _PromptGeneratorState();
}

class _PromptGeneratorState extends State<PromptGenerator> {
  String currentPrompt = "(select a key)";
  final List<String> _history = [];

  void addText(String text) {
    setState(() {
      _history.add(currentPrompt);
      if (currentPrompt == "(select a key)" || currentPrompt.isEmpty) {
        currentPrompt = text;
      } else {
        currentPrompt += "\\n$text";
      }
    });
    HapticFeedback.lightImpact();
  }

  void clearPrompt() {
    setState(() {
      _history.add(currentPrompt);
      currentPrompt = "(select a key)";
    });
    HapticFeedback.mediumImpact();
  }

  void copyPrompt() {
    if (currentPrompt == "(select a key)" || currentPrompt.isEmpty) return;
    Clipboard.setData(ClipboardData(text: currentPrompt));
    HapticFeedback.heavyImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Prompt copied to clipboard!"),
        backgroundColor: Colors.amber,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "INVOKERSYNY PROMPT BUILDER",
          style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // 1. DISPLAY SCREEN: Vintage Beige LCD Screen (#E5D1B0)
            Container(
              margin: const EdgeInsets.all(12),
              padding: const EdgeInsets.all(16),
              height: 240,
              width: double.infinity,
              decoration: BoxDecoration(
                color: const Color(0xFFE5D1B0),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF32363E), width: 3),
                boxShadow: const [
                  BoxShadow(color: Colors.black54, blurRadius: 8, offset: Offset(0, 4)),
                ],
              ),
              child: SingleChildScrollView(
                child: SelectableText(
                  currentPrompt,
                  style: const TextStyle(
                    color: Colors.black87,
                    fontSize: 16,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600,
                    height: 1.4,
                  ),
                ),
              ),
            ),

            // 2. SHORT CODE BUTTONS (The Keyboard)
            Expanded(
              child: GridView.count(
                crossAxisCount: 4,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                childAspectRatio: 1.0,
                children: [
                  _buildButton("F", "Clip", "Clip: First Clip"),
                  _buildButton("T", "Time", "Time: 00:00-00:05"),
                  _buildButton("C", "Camera", "Camera: Bird's Eye View"),
                  _buildButton("S", "Style", "Style: Cinematic Anime"),
                  _buildButton("CU", "Close-Up", "Camera: Extreme Close-Up Macro"),
                  _buildButton("FP", "FPV Drone", "Camera: Fast FPV Drone Flythrough"),
                  _buildButton("DO", "Dolly Zoom", "Camera: Hitchcock Vertigo Dolly Zoom"),
                  _buildButton("OR", "Orbit 360", "Camera: 360° Smooth Orbiting Pan"),
                  _buildButton("GH", "Golden Hr", "Lighting: Golden Hour Warm Sunflare"),
                  _buildButton("NE", "Neon Rim", "Lighting: Neon Magenta Rim Lighting"),
                  _buildButton("VO", "Volumetric", "Lighting: Heavy Volumetric God Rays"),
                  _buildButton("16M", "16mm Film", "Style: Authentic 16mm Grain Kodak 500T"),
                  _buildButton("SM", "Slow-Mo", "Motion: 120fps Bullet-Time Hyper Slow-Mo"),
                  _buildButton("FA", "Action", "Motion: Kinetic High-Octane Action Blur"),
                  _buildButton("4K", "4K UHD", "Quality: Mastered in 4K UHD Pro-Res"),
                  _buildButton("AR", "16:9 Aspect", "Aspect Ratio: 16:9 Widescreen"),
                ],
              ),
            ),

            // 3. ACTION BUTTONS
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF282B32),
                        foregroundColor: Colors.redAccent,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: clearPrompt,
                      icon: const Icon(Icons.delete_outline),
                      label: const Text("CLEAR", style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orangeAccent,
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      onPressed: copyPrompt,
                      icon: const Icon(Icons.copy),
                      label: const Text("COPY PROMPT", style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildButton(String code, String label, String value) {
    return GestureDetector(
      onTap: () => addText(value),
      child: Container(
        margin: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: Colors.orangeAccent,
          borderRadius: BorderRadius.circular(8),
          boxShadow: const [
            BoxShadow(color: Colors.black38, blurRadius: 4, offset: Offset(0, 2)),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              code,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: Colors.black87),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}
`;

  const cliCommands = `# 1. Create a Flutter project
flutter create invokersyny_prompt_builder
cd invokersyny_prompt_builder

# 2. Replace lib/main.dart with the provided code

# 3. Assemble and build release Android APK
flutter build apk --release

# 4. Your APK will be assembled at:
# build/app/outputs/flutter-apk/app-release.apk
`;

  const handleCopyFlutter = () => {
    navigator.clipboard.writeText(flutterSourceCode);
    setCopiedFlutter(true);
    setTimeout(() => setCopiedFlutter(false), 2000);
  };

  const handleCopyCli = () => {
    navigator.clipboard.writeText(cliCommands);
    setCopiedCli(true);
    setTimeout(() => setCopiedCli(false), 2000);
  };

  const handleDownloadDart = () => {
    const blob = new Blob([flutterSourceCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'main.dart';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs">
      <div className="bg-[#191b20] border border-[#323640] rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl relative text-neutral-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#292d36]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base tracking-wide font-mono text-white">
                ANDROID BUILD & INSTALL CENTER
              </h3>
              <p className="text-xs text-neutral-400 font-mono">
                Install as Android WebAPK or assemble native Flutter APK
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex items-center border-b border-[#292d36] bg-[#141519] px-4 pt-2 gap-2 text-xs font-mono">
          <button
            type="button"
            onClick={() => setActiveTab('direct')}
            className={`pb-2.5 px-3 border-b-2 font-bold transition-all ${
              activeTab === 'direct'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            1. DIRECT ANDROID INSTALL (WEBAPK)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('flutter')}
            className={`pb-2.5 px-3 border-b-2 font-bold transition-all ${
              activeTab === 'flutter'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            2. FLUTTER BUILD APK (.APK)
          </button>
        </div>

        {/* Tab Contents */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {activeTab === 'direct' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-gradient-to-br from-[#20242c] to-[#17191e] border border-amber-500/30">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="inline-block px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold mb-1.5 border border-emerald-500/30">
                      RECOMMENDED &bull; READY TO INSTALL NOW
                    </span>
                    <h4 className="text-sm font-bold text-white">Instant Android Standalone App (WebAPK)</h4>
                    <p className="text-xs text-neutral-300 mt-1">
                      Android devices (Chrome, Edge, Samsung Internet) automatically convert this app into a signed
                      <strong> Android APK / WebAPK</strong> that installs onto your home screen with its own app icon,
                      launches full-screen without URL bar, and works offline.
                    </p>
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap items-center gap-3">
                  {isInstallable ? (
                    <button
                      type="button"
                      onClick={install}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold font-mono text-xs transition-all shadow-lg shadow-amber-500/20 active:scale-95"
                    >
                      <Download className="w-4 h-4" />
                      <span>INSTALL ON ANDROID NOW</span>
                    </button>
                  ) : isInstalled ? (
                    <div className="flex items-center gap-2 text-xs font-mono text-emerald-400">
                      <Check className="w-4 h-4" />
                      <span>ALREADY INSTALLED IN STANDALONE MODE!</span>
                    </div>
                  ) : (
                    <div className="text-xs font-mono text-neutral-300 bg-[#121417] p-3 rounded-lg border border-neutral-700 w-full space-y-1">
                      <p className="font-semibold text-amber-400">How to install on Android device:</p>
                      <p>1. Open this app URL in <strong>Chrome</strong> on your Android phone.</p>
                      <p>2. Tap the browser menu <strong>(3 vertical dots ⋮)</strong> in the top-right.</p>
                      <p>3. Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</p>
                      <p className="text-neutral-400 text-[11px] pt-1">Android will generate the WebAPK and add the Invokersyny icon to your app drawer!</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#14161a] border border-[#2a2d36] text-xs space-y-2">
                <div className="flex items-center gap-2 text-neutral-300 font-semibold font-mono">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>PWA Specifications Configured:</span>
                </div>
                <ul className="list-disc list-inside text-neutral-400 space-y-1 text-[11px] font-mono">
                  <li>Display mode: <strong>standalone</strong> (hides browser UI)</li>
                  <li>Adaptive Maskable Icons: <strong>192x192</strong> & <strong>512x512</strong></li>
                  <li>Auto-updating Service Worker for offline caching</li>
                  <li>Theme status bar: <strong>#16181D</strong></li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'flutter' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-[#14161a] border border-[#2c303a]">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-amber-400" />
                    <span className="font-mono text-xs font-bold text-neutral-200">
                      FLUTTER APK BUILD COMMANDS
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyCli}
                    className="flex items-center gap-1 text-[11px] font-mono text-amber-400 hover:text-amber-300"
                  >
                    {copiedCli ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedCli ? 'COPIED' : 'COPY COMMANDS'}</span>
                  </button>
                </div>
                <pre className="text-[11px] font-mono bg-[#0c0d10] p-3 rounded-lg text-neutral-300 overflow-x-auto border border-neutral-800">
                  {cliCommands}
                </pre>
              </div>

              <div className="p-3 rounded-xl bg-[#14161a] border border-[#2c303a]">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-xs font-bold text-neutral-200">
                    FLUTTER SOURCE CODE (lib/main.dart)
                  </span>
                  <div className="flex items-center gap-2">
                    <a
                      href="/invokersyny-flutter-project.zip"
                      download="invokersyny-flutter-project.zip"
                      className="flex items-center gap-1 text-[11px] font-mono px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded"
                    >
                      <Download className="w-3 h-3" />
                      <span>DOWNLOAD FULL PROJECT (.ZIP)</span>
                    </a>
                    <button
                      type="button"
                      onClick={handleDownloadDart}
                      className="flex items-center gap-1 text-[11px] font-mono px-2 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded border border-neutral-700"
                    >
                      <Download className="w-3 h-3" />
                      <span>.DART ONLY</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleCopyFlutter}
                      className="flex items-center gap-1 text-[11px] font-mono px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded"
                    >
                      {copiedFlutter ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedFlutter ? 'COPIED' : 'COPY CODE'}</span>
                    </button>
                  </div>
                </div>
                <pre className="text-[11px] font-mono bg-[#0c0d10] p-3 rounded-lg text-amber-200/90 overflow-x-auto max-h-56 border border-neutral-800">
                  {flutterSourceCode}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#292d36] bg-[#14161a] flex items-center justify-between text-xs font-mono">
          <span className="text-neutral-400">Target: Android OS 5.0+ (Lollipop to Android 15)</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 text-neutral-300 hover:bg-neutral-700 transition-colors"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
