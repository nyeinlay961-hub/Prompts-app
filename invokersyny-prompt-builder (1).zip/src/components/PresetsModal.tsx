import React from 'react';
import { PromptPreset } from '../types';
import { X, Sparkles, ArrowRight, Play } from 'lucide-react';

interface PresetsModalProps {
  isOpen: boolean;
  onClose: () => void;
  presets: PromptPreset[];
  onLoadPreset: (preset: PromptPreset) => void;
}

export const PresetsModal: React.FC<PresetsModalProps> = ({
  isOpen,
  onClose,
  presets,
  onLoadPreset,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-[#1e2127] border border-[#333842] rounded-xl w-full max-w-xl max-h-[85vh] flex flex-col shadow-2xl relative text-neutral-200">
        <div className="flex items-center justify-between p-4 border-b border-[#2d323b]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <h3 className="font-bold text-base tracking-wide font-mono text-white">
              CINEMATIC PRESET STACKS
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <p className="text-xs text-neutral-400">
            Select a curated prompt sequence to instantly populate your prompt generator:
          </p>

          <div className="grid grid-cols-1 gap-3">
            {presets.map((preset) => (
              <div
                key={preset.id}
                className="p-3.5 rounded-lg bg-[#14161a] border border-neutral-800 hover:border-amber-500/50 transition-all group flex flex-col justify-between gap-3"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold font-mono text-sm text-amber-400">{preset.name}</h4>
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-800 text-neutral-400">
                      {preset.items.length} KEYS
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400 mt-1">{preset.description}</p>
                </div>

                {/* Tags preview */}
                <div className="flex flex-wrap gap-1">
                  {preset.items.slice(0, 4).map((item, idx) => (
                    <span
                      key={idx}
                      className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#1e2229] text-neutral-300 border border-neutral-700/60"
                    >
                      {item}
                    </span>
                  ))}
                  {preset.items.length > 4 && (
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#1e2229] text-neutral-500">
                      +{preset.items.length - 4} more
                    </span>
                  )}
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      onLoadPreset(preset);
                      onClose();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold font-mono transition-colors active:scale-95 shadow-sm"
                  >
                    <Play className="w-3 h-3 fill-black" />
                    <span>LOAD THIS STACK</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
