import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Smartphone } from 'lucide-react';

interface PWAInstallButtonProps {
  onOpenAndroidModal: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ onOpenAndroidModal }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed standalone PWA, show a minimal installed indicator or let them view APK options
  if (isInstalled) {
    return (
      <button
        id="apk-center-btn"
        type="button"
        onClick={onOpenAndroidModal}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#21242b] hover:bg-[#2b303a] text-emerald-400 border border-emerald-500/30 text-xs font-mono font-semibold transition-colors"
        title="Android APK Center"
      >
        <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
        <span>APK / PWA</span>
      </button>
    );
  }

  // If installable (Chromium/Android browser)
  if (isInstallable) {
    return (
      <button
        id="pwa-install-app-btn"
        type="button"
        onClick={install}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black border border-emerald-300 text-xs font-mono font-bold transition-all shadow-md shadow-emerald-500/20 active:scale-95 animate-pulse"
        title="Install as Android App"
      >
        <Download className="w-3.5 h-3.5" />
        <span>INSTALL APK</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#21242b] hover:bg-[#2b303a] text-neutral-300 border border-neutral-700 text-xs font-mono transition-colors"
        >
          <Smartphone className="w-3.5 h-3.5 text-neutral-400" />
          <span>INSTALL</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
            <div className="w-full max-w-sm rounded-xl bg-[#1e2127] border border-neutral-700 p-5 shadow-2xl text-neutral-200 font-sans">
              <h3 className="text-base font-bold text-white font-mono">INSTALL ON IPHONE / IPAD</h3>
              <p className="mt-2 text-xs text-neutral-400 leading-relaxed">
                1. Tap the <strong>Share</strong> button in Safari toolbar.<br />
                2. Scroll down and tap <strong>Add to Home Screen</strong>.
              </p>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-4 w-full rounded-lg bg-neutral-800 hover:bg-neutral-700 py-2 text-xs font-mono text-neutral-200 border border-neutral-700"
              >
                CLOSE
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  // Default fallback: Always accessible Android APK & Install Center button
  return (
    <button
      id="open-android-apk-modal-btn"
      type="button"
      onClick={onOpenAndroidModal}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#21242b] hover:bg-[#2b303a] text-amber-400 border border-amber-500/40 text-xs font-mono font-semibold transition-all active:scale-95 shadow-sm"
      title="Open Android APK & Installation Center"
    >
      <Smartphone className="w-3.5 h-3.5" />
      <span>ANDROID APK</span>
    </button>
  );
};
