import React, { useState, useRef, useEffect } from 'react';
import { PromptFormat } from '../types';
import { Copy, Check, RotateCcw, Trash2, Edit3, Eye, Download } from 'lucide-react';

interface DisplayScreenProps {
  promptText: string;
  onPromptChange: (text: string) => void;
  onClear: () => void;
  onCopy: () => void;
  onUndo: () => void;
  format: PromptFormat;
  onFormatChange: (format: PromptFormat) => void;
  historyCount: number;
}

export const DisplayScreen: React.FC<DisplayScreenProps> = ({
  promptText,
  onPromptChange,
  onClear,
  onCopy,
  onUndo,
  format,
  onFormatChange,
  historyCount,
}) => {
  const [isCopied, setIsCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const isDefaultPlaceholder = promptText === '(select a key)' || promptText.trim() === '';

  const handleCopy = () => {
    if (isDefaultPlaceholder) return;
    navigator.clipboard.writeText(formattedDisplayPrompt);
    setIsCopied(true);
    onCopy();
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Convert multi-line to comma separated if format is comma
  const formattedDisplayPrompt = React.useMemo(() => {
    if (isDefaultPlaceholder) return '(select a key)';
    if (format === 'comma') {
      return promptText
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean)
        .join(', ');
    }
    return promptText;
  }, [promptText, format, isDefaultPlaceholder]);

  const handleDownload = () => {
    if (isDefaultPlaceholder) return;
    const blob = new Blob([formattedDisplayPrompt], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `invokersyny-prompt-${Date.now()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Focus textarea when entering edit mode
  useEffect(() => {
    if (isEditing && textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [isEditing]);

  const lines = promptText.split('\n').filter(Boolean);
  const wordCount = isDefaultPlaceholder ? 0 : promptText.trim().split(/\s+/).filter(Boolean).length;
  const charCount = isDefaultPlaceholder ? 0 : promptText.length;

  return (
    <div id="display-screen-container" className="w-full">
      {/* Vintage Hardware Screen Bezel */}
      <div className="bg-[#1e2024] border-2 border-[#32363e] rounded-xl p-3 shadow-2xl relative">
        {/* Hardware Status Header Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 mb-2 border-b border-[#2d3139] text-xs font-mono text-neutral-400">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.7)]" />
            <span className="font-semibold tracking-wider text-neutral-300">LCD BUFFER 1024B</span>
            <span className="hidden sm:inline-block text-neutral-600">|</span>
            <span className="hidden sm:inline-block text-neutral-400">
              {isDefaultPlaceholder ? 'READY' : `${lines.length} ${lines.length === 1 ? 'LINE' : 'LINES'}`}
            </span>
          </div>

          <div className="flex items-center gap-2 text-[11px]">
            {/* Format toggle: Multi-line vs Comma */}
            <div className="bg-[#121316] p-0.5 rounded flex items-center border border-[#30343c]">
              <button
                id="format-multiline-btn"
                type="button"
                onClick={() => onFormatChange('multiline')}
                className={`px-2 py-0.5 rounded transition-colors ${
                  format === 'multiline'
                    ? 'bg-amber-500 text-black font-bold'
                    : 'text-neutral-400 hover:text-white'
                }`}
                title="Line by line format"
              >
                MULTI-LINE
              </button>
              <button
                id="format-comma-btn"
                type="button"
                onClick={() => onFormatChange('comma')}
                className={`px-2 py-0.5 rounded transition-colors ${
                  format === 'comma'
                    ? 'bg-amber-500 text-black font-bold'
                    : 'text-neutral-400 hover:text-white'
                }`}
                title="Comma separated prompt (Midjourney/Runway format)"
              >
                COMMA-JOIN
              </button>
            </div>

            {/* Direct Edit Mode Toggle */}
            <button
              id="toggle-edit-mode-btn"
              type="button"
              onClick={() => {
                if (isDefaultPlaceholder && !isEditing) {
                  onPromptChange('');
                }
                setIsEditing(!isEditing);
              }}
              className={`flex items-center gap-1 px-2 py-1 rounded border transition-colors ${
                isEditing
                  ? 'bg-amber-600/30 border-amber-500/50 text-amber-300'
                  : 'bg-[#282b32] border-[#3e434e] text-neutral-300 hover:bg-[#32363f]'
              }`}
              title={isEditing ? 'Switch to View Mode' : 'Direct Keyboard Edit'}
            >
              {isEditing ? <Eye className="w-3 h-3" /> : <Edit3 className="w-3 h-3" />}
              <span>{isEditing ? 'PREVIEW' : 'EDIT'}</span>
            </button>
          </div>
        </div>

        {/* 1. DISPLAY SCREEN: Authentic Beige Box Color: #E5D1B0 from user's Flutter code */}
        <div
          id="retro-lcd-screen"
          className="relative min-h-[220px] max-h-[340px] w-full rounded-lg overflow-hidden shadow-inner flex flex-col transition-all"
          style={{
            backgroundColor: '#E5D1B0', // Signature beige color from user code
            backgroundImage:
              'radial-gradient(#d3be9c 0.8px, transparent 0.8px), radial-gradient(#d3be9c 0.8px, #E5D1B0 0.8px)',
            backgroundSize: '20px 20px',
            backgroundPosition: '0 0, 10px 10px',
          }}
        >
          {/* Subtle CRT / LCD Glare overlay */}
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-white/10 via-transparent to-black/10 opacity-70" />

          {/* Prompt Content Container */}
          <div className="relative z-10 flex-1 p-4 md:p-5 overflow-y-auto">
            {isEditing ? (
              <textarea
                ref={textareaRef}
                id="prompt-manual-textarea"
                value={promptText === '(select a key)' ? '' : promptText}
                onChange={(e) => onPromptChange(e.target.value)}
                placeholder="Type or click keys below to assemble your prompt..."
                className="w-full h-full min-h-[170px] bg-transparent text-neutral-900 font-mono text-[15px] md:text-[16px] leading-relaxed resize-none focus:outline-none border-none placeholder:text-neutral-600/70 select-text"
                spellCheck={false}
              />
            ) : (
              <div
                id="prompt-text-display"
                onClick={() => {
                  if (isDefaultPlaceholder) {
                    onPromptChange('');
                  }
                  setIsEditing(true);
                }}
                className="w-full h-full min-h-[170px] text-neutral-950 font-mono text-[15px] md:text-[16px] leading-relaxed whitespace-pre-wrap select-text cursor-text"
              >
                {isDefaultPlaceholder ? (
                  <div className="flex flex-col items-center justify-center min-h-[160px] text-neutral-700/80 text-center select-none">
                    <span className="text-xl md:text-2xl font-bold tracking-wider font-mono opacity-80 animate-pulse">
                      (select a key)
                    </span>
                    <p className="text-xs md:text-sm mt-2 text-neutral-600 max-w-md font-sans">
                      Press any short-code pad below (or physical hotkeys) to build your cinematic AI prompt stack.
                    </p>
                  </div>
                ) : (
                  <div>
                    {format === 'comma' ? (
                      <span className="font-semibold">{formattedDisplayPrompt}</span>
                    ) : (
                      lines.map((line, idx) => (
                        <div key={idx} className="flex items-start gap-2 py-0.5 group">
                          <span className="text-neutral-500/80 select-none text-xs font-mono pt-1">
                            {String(idx + 1).padStart(2, '0')}
                          </span>
                          <span className="flex-1 font-medium">{line}</span>
                        </div>
                      ))
                    )}
                    {/* Blinking retro cursor */}
                    <span className="inline-block w-2.5 h-4 ml-1 bg-neutral-900 animate-pulse align-middle" />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Quick HUD status strip inside LCD */}
          <div className="relative z-10 px-4 py-1.5 bg-[#d8c29e]/80 border-t border-[#c5b08c] flex items-center justify-between text-[11px] font-mono text-neutral-800">
            <div className="flex items-center gap-3">
              <span>CHARS: <strong className="font-semibold">{charCount}</strong></span>
              <span>WORDS: <strong className="font-semibold">{wordCount}</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <span className="opacity-75">INVOKERSYNY OS v1.0</span>
            </div>
          </div>
        </div>

        {/* Action Shortcuts Ribbon Below LCD */}
        <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-2">
          <div className="flex items-center gap-2">
            <button
              id="undo-last-btn"
              type="button"
              disabled={historyCount <= 0 || isDefaultPlaceholder}
              onClick={onUndo}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
                historyCount > 0 && !isDefaultPlaceholder
                  ? 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700 active:scale-95 border border-neutral-700'
                  : 'bg-neutral-900/50 text-neutral-600 border border-neutral-800/50 cursor-not-allowed'
              }`}
              title="Undo last added key"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>UNDO ({historyCount})</span>
            </button>

            <button
              id="clear-prompt-quick-btn"
              type="button"
              disabled={isDefaultPlaceholder}
              onClick={onClear}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
                !isDefaultPlaceholder
                  ? 'bg-rose-950/40 text-rose-300 hover:bg-rose-900/60 border border-rose-800/60 active:scale-95'
                  : 'bg-neutral-900/50 text-neutral-600 border border-neutral-800/50 cursor-not-allowed'
              }`}
              title="Reset prompt buffer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>CLEAR</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="download-txt-btn"
              type="button"
              disabled={isDefaultPlaceholder}
              onClick={handleDownload}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wider transition-all ${
                !isDefaultPlaceholder
                  ? 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700 border border-neutral-700 active:scale-95'
                  : 'bg-neutral-900/50 text-neutral-600 border border-neutral-800/50 cursor-not-allowed'
              }`}
              title="Export as .txt file"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">EXPORT</span>
            </button>

            <button
              id="copy-prompt-quick-btn"
              type="button"
              disabled={isDefaultPlaceholder}
              onClick={handleCopy}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all shadow-md active:scale-95 ${
                isCopied
                  ? 'bg-emerald-500 text-black border border-emerald-400'
                  : !isDefaultPlaceholder
                  ? 'bg-amber-500 hover:bg-amber-400 text-black border border-amber-400 shadow-amber-500/20'
                  : 'bg-neutral-800 text-neutral-600 border border-neutral-700 cursor-not-allowed'
              }`}
            >
              {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{isCopied ? 'COPIED!' : 'COPY PROMPT'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
