import React, { useState } from 'react';
import { PromptButton } from '../types';
import { KeyboardButton } from './KeyboardButton';
import { Search, Plus, Filter, Sparkles, Layers } from 'lucide-react';

interface KeyboardGridProps {
  buttons: PromptButton[];
  onButtonPress: (button: PromptButton) => void;
  onDeleteCustom?: (id: string) => void;
  onOpenAddCustom: () => void;
  activePromptLines: string[];
}

export const KeyboardGrid: React.FC<KeyboardGridProps> = ({
  buttons,
  onButtonPress,
  onDeleteCustom,
  onOpenAddCustom,
  activePromptLines,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categories = [
    { id: 'all', label: 'All Pads' },
    { id: 'clip', label: 'Clip & Time' },
    { id: 'camera', label: 'Camera' },
    { id: 'style', label: 'Styles' },
    { id: 'lighting', label: 'Lighting' },
    { id: 'motion', label: 'Motion' },
    { id: 'specs', label: 'Specs' },
    { id: 'custom', label: 'Custom' },
  ];

  const filteredButtons = buttons.filter((btn) => {
    const matchesCat =
      selectedCategory === 'all'
        ? true
        : selectedCategory === 'custom'
        ? btn.isCustom
        : btn.category === selectedCategory;

    const query = searchQuery.toLowerCase().trim();
    const matchesSearch =
      query === '' ||
      btn.code.toLowerCase().includes(query) ||
      btn.label.toLowerCase().includes(query) ||
      btn.value.toLowerCase().includes(query);

    return matchesCat && matchesSearch;
  });

  return (
    <div id="keyboard-grid-section" className="w-full flex flex-col gap-3">
      {/* Grid Controller Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 pb-1">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-bold tracking-wider uppercase text-neutral-300 font-mono">
            SHORT CODE KEYBOARD
          </h2>
          <span className="text-xs px-2 py-0.5 rounded-full bg-neutral-800 text-amber-400/90 font-mono border border-neutral-700">
            {filteredButtons.length} PADS
          </span>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          {/* Quick Search */}
          <div className="relative flex-1 sm:w-48">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-neutral-500" />
            <input
              id="search-pads-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search code or tag..."
              className="w-full pl-8 pr-2.5 py-1 text-xs bg-[#17191d] border border-neutral-700 rounded-lg text-neutral-200 placeholder:text-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Add Custom Key Button */}
          <button
            id="add-custom-pad-btn"
            type="button"
            onClick={onOpenAddCustom}
            className="flex items-center gap-1 px-3 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors active:scale-95"
            title="Create your own short code button"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>CUSTOM KEY</span>
          </button>
        </div>
      </div>

      {/* Category Pills Slider */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
        {categories.map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3 py-1 rounded-md whitespace-nowrap transition-all uppercase tracking-wide font-mono text-[11px] ${
              selectedCategory === cat.id
                ? 'bg-amber-500 text-black font-bold shadow-sm shadow-amber-500/20'
                : 'bg-[#1e2126] text-neutral-400 hover:text-neutral-200 hover:bg-[#282c33] border border-neutral-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* 2. THE KEYBOARD: 4-column GridView as specified in Flutter code */}
      <div
        id="prompt-pads-grid"
        className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 gap-2.5 p-3 rounded-xl bg-[#18191d] border border-[#272a31] shadow-inner"
      >
        {filteredButtons.length > 0 ? (
          filteredButtons.map((btn) => {
            const isActive = activePromptLines.some(
              (line) => line.trim().toLowerCase() === btn.value.trim().toLowerCase()
            );
            return (
              <KeyboardButton
                key={btn.id}
                button={btn}
                onPress={onButtonPress}
                onDeleteCustom={onDeleteCustom}
                isActiveInPrompt={isActive}
              />
            );
          })
        ) : (
          <div className="col-span-full py-10 flex flex-col items-center justify-center text-center text-neutral-500">
            <Filter className="w-8 h-8 mb-2 opacity-40 text-neutral-400" />
            <p className="text-sm font-medium text-neutral-400">No buttons found matching "{searchQuery}"</p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="mt-2 text-xs text-amber-400 underline hover:text-amber-300"
            >
              Reset filters
            </button>
          </div>
        )}
      </div>

      {/* Keyboard Shortcut Hint */}
      <div className="flex items-center justify-between px-1 text-[11px] font-mono text-neutral-500">
        <span>TIP: Click any pad to append to prompt buffer.</span>
        <span className="hidden sm:inline">ORIGINAL PRESETS: F, T, C, S</span>
      </div>
    </div>
  );
};
