import React from 'react';
import { PromptButton } from '../types';
import { motion } from 'motion/react';
import { Trash2 } from 'lucide-react';

interface KeyboardButtonProps {
  button: PromptButton;
  onPress: (button: PromptButton) => void;
  onDeleteCustom?: (id: string) => void;
  isActiveInPrompt?: boolean;
}

export const KeyboardButton: React.FC<KeyboardButtonProps> = ({
  button,
  onPress,
  onDeleteCustom,
  isActiveInPrompt,
}) => {
  return (
    <div className="relative group p-1 w-full h-full min-h-[82px] flex">
      <motion.button
        id={`key-btn-${button.id}`}
        type="button"
        whileHover={{ scale: 1.03, y: -2 }}
        whileTap={{ scale: 0.94, y: 1 }}
        transition={{ type: 'spring', stiffness: 450, damping: 25 }}
        onClick={() => onPress(button)}
        title={`Click to add: "${button.value}"`}
        className={`relative w-full h-full p-2.5 rounded-lg flex flex-col items-center justify-center text-center select-none shadow-md transition-shadow cursor-pointer overflow-hidden border ${
          isActiveInPrompt
            ? 'border-amber-300 ring-2 ring-amber-400/50 shadow-amber-500/30'
            : 'border-amber-600/60 hover:border-amber-400/80 shadow-black/40'
        }`}
        style={{
          // Authentic Flutter Colors.orangeAccent: #FFAB40 with subtle gradient depth
          background: 'linear-gradient(145deg, #FFB74D 0%, #FF9800 65%, #F57C00 100%)',
          color: '#111315',
        }}
      >
        {/* Subtle pad highlight bevel */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-1 bg-white/40 rounded-t-lg" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1 bg-black/25 rounded-b-lg" />

        {/* Short Code: Text(code, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)) */}
        <span className="text-lg sm:text-xl font-extrabold tracking-tight font-mono leading-none drop-shadow-[0_1px_1px_rgba(255,255,255,0.4)]">
          {button.code}
        </span>

        {/* Label: Text(label, style: TextStyle(fontSize: 12)) */}
        <span className="text-[11px] sm:text-xs font-semibold tracking-wide uppercase mt-1 leading-tight text-neutral-900/90 truncate max-w-full">
          {button.label}
        </span>

        {/* Active counter dot if line exists in prompt */}
        {isActiveInPrompt && (
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-950 ring-2 ring-emerald-400" />
        )}
      </motion.button>

      {/* Delete button for user-created custom keys */}
      {button.isCustom && onDeleteCustom && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDeleteCustom(button.id);
          }}
          className="absolute -top-1 -right-1 z-20 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md hover:bg-rose-700"
          title="Delete custom button"
        >
          <Trash2 className="w-3 h-3" />
        </button>
      )}
    </div>
  );
};
