import React, { useState } from 'react';
import { Trash2, Copy, Check, Volume2, VolumeX, Sparkles, BookOpen } from 'lucide-react';
import { motion } from 'motion/react';

interface ActionBarProps {
  onClear: () => void;
  onCopy: () => void;
  onOpenPresets: () => void;
  isMuted: boolean;
  onToggleSound: () => void;
  hasPrompt: boolean;
  formattedText: string;
}

export const ActionBar: React.FC<ActionBarProps> = ({
  onClear,
  onCopy,
  onOpenPresets,
  isMuted,
  onToggleSound,
  hasPrompt,
  formattedText,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopyClick = () => {
    if (!hasPrompt) return;
    navigator.clipboard.writeText(formattedText);
    setCopied(true);
    onCopy();
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      id="action-buttons-container"
      className="w-full bg-[#1b1d22] border-t border-[#292d36] p-4 rounded-xl shadow-xl flex flex-col sm:flex-row items-center justify-between gap-3"
    >
      {/* Secondary Tools: Sound & Presets */}
      <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-start">
        {/* Preset Templates */}
        <button
          id="open-presets-btn"
          type="button"
          onClick={onOpenPresets}
          className="flex items-center gap-2 px-3.5 py-2.5 rounded-lg bg-[#252830] hover:bg-[#2e323c] text-neutral-300 border border-neutral-700 text-xs font-semibold uppercase tracking-wider transition-all active:scale-95"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>PRESET STACKS</span>
        </button>

        {/* Tactile Sound Toggle */}
        <button
          id="toggle-sound-btn"
          type="button"
          onClick={onToggleSound}
          className={`flex items-center gap-1.5 px-3 py-2.5 rounded-lg border text-xs font-mono transition-all ${
            isMuted
              ? 'bg-[#1e2025] text-neutral-500 border-neutral-800 hover:text-neutral-300'
              : 'bg-[#252830] text-amber-400 border-amber-500/30'
          }`}
          title={isMuted ? 'Turn Sound ON' : 'Turn Sound OFF'}
        >
          {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          <span className="hidden md:inline">{isMuted ? 'MUTED' : 'FX ON'}</span>
        </button>
      </div>

      {/* 3. Primary Action Buttons: Exact Flutter Match */}
      <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
        {/* CLEAR Button */}
        <motion.button
          id="action-clear-btn"
          type="button"
          whileHover={{ scale: hasPrompt ? 1.02 : 1 }}
          whileTap={{ scale: hasPrompt ? 0.96 : 1 }}
          onClick={onClear}
          disabled={!hasPrompt}
          className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold font-mono text-sm tracking-wider uppercase transition-all shadow-md ${
            hasPrompt
              ? 'bg-neutral-800 hover:bg-neutral-700 text-rose-300 border border-neutral-700 hover:border-rose-500/40 cursor-pointer'
              : 'bg-neutral-900/60 text-neutral-600 border border-neutral-800 cursor-not-allowed opacity-50'
          }`}
        >
          <Trash2 className="w-4 h-4" />
          <span>CLEAR</span>
        </motion.button>

        {/* COPY PROMPT Button */}
        <motion.button
          id="action-copy-prompt-btn"
          type="button"
          whileHover={{ scale: hasPrompt ? 1.03 : 1 }}
          whileTap={{ scale: hasPrompt ? 0.96 : 1 }}
          onClick={handleCopyClick}
          disabled={!hasPrompt}
          className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-7 py-3 rounded-xl font-extrabold font-mono text-sm tracking-wider uppercase transition-all shadow-lg ${
            copied
              ? 'bg-emerald-500 text-black border-2 border-emerald-300 shadow-emerald-500/30'
              : hasPrompt
              ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black border-2 border-amber-400 shadow-amber-500/25 cursor-pointer'
              : 'bg-neutral-800 text-neutral-600 border border-neutral-700 cursor-not-allowed opacity-50'
          }`}
        >
          {copied ? (
            <>
              <Check className="w-4 h-4" />
              <span>COPIED!</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span>COPY PROMPT</span>
            </>
          )}
        </motion.button>
      </div>
    </div>
  );
};
