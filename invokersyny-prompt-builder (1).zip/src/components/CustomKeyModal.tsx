import React, { useState } from 'react';
import { PromptButton } from '../types';
import { X, Plus, Sparkles } from 'lucide-react';

interface CustomKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (button: Omit<PromptButton, 'id' | 'isCustom'>) => void;
}

export const CustomKeyModal: React.FC<CustomKeyModalProps> = ({ isOpen, onClose, onSave }) => {
  const [code, setCode] = useState('');
  const [label, setLabel] = useState('');
  const [value, setValue] = useState('');
  const [category, setCategory] = useState<PromptButton['category']>('custom');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !label.trim() || !value.trim()) return;

    onSave({
      code: code.trim().toUpperCase().slice(0, 4),
      label: label.trim(),
      value: value.trim(),
      category,
    });

    setCode('');
    setLabel('');
    setValue('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="bg-[#1e2127] border border-[#333842] rounded-xl w-full max-w-md p-5 shadow-2xl relative text-neutral-200">
        <div className="flex items-center justify-between pb-3 border-b border-[#2d323b]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <h3 className="font-bold text-base tracking-wide font-mono text-white">ADD CUSTOM PAD KEY</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-mono font-medium text-neutral-400 mb-1">
                KEY CODE (1-4 Chars)
              </label>
              <input
                type="text"
                maxLength={4}
                required
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="e.g. DR, VFX"
                className="w-full px-3 py-2 bg-[#14161a] border border-neutral-700 rounded-lg text-amber-400 font-mono font-bold text-sm focus:outline-none focus:border-amber-500 uppercase"
              />
            </div>

            <div>
              <label className="block text-xs font-mono font-medium text-neutral-400 mb-1">
                PAD LABEL
              </label>
              <input
                type="text"
                required
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                placeholder="e.g. Dragon, Lens FX"
                className="w-full px-3 py-2 bg-[#14161a] border border-neutral-700 rounded-lg text-neutral-200 text-sm focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono font-medium text-neutral-400 mb-1">
              PROMPT TEXT TO INSERT
            </label>
            <textarea
              rows={3}
              required
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="e.g. Subject: Ancient dragon perched atop a neon skyscraper, cinematic hyper-detailed"
              className="w-full px-3 py-2 bg-[#14161a] border border-neutral-700 rounded-lg text-neutral-200 text-sm focus:outline-none focus:border-amber-500 font-mono resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-mono font-medium text-neutral-400 mb-1">
              CATEGORY
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as PromptButton['category'])}
              className="w-full px-3 py-2 bg-[#14161a] border border-neutral-700 rounded-lg text-neutral-300 text-sm focus:outline-none focus:border-amber-500"
            >
              <option value="custom">Custom Bank</option>
              <option value="clip">Clip & Timing</option>
              <option value="camera">Camera & Angle</option>
              <option value="style">Style & Aesthetics</option>
              <option value="lighting">Lighting</option>
              <option value="motion">Motion & FX</option>
              <option value="specs">Technical Specs</option>
            </select>
          </div>

          {/* Live Preview of the Pad */}
          <div className="pt-2">
            <span className="block text-[11px] font-mono text-neutral-500 mb-1.5">PAD PREVIEW</span>
            <div className="w-28 h-20 mx-auto rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 p-2 flex flex-col items-center justify-center text-center text-black border border-amber-300 shadow-md">
              <span className="text-xl font-mono font-black">{code || 'KEY'}</span>
              <span className="text-xs font-semibold uppercase truncate max-w-full">
                {label || 'Label'}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#2d323b]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-mono text-neutral-400 hover:text-white bg-neutral-800"
            >
              CANCEL
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 rounded-lg text-xs font-bold font-mono text-black bg-amber-500 hover:bg-amber-400 transition-colors shadow-md"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>SAVE KEY</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
