export interface PromptButton {
  id: string;
  code: string;
  label: string;
  value: string;
  category: 'clip' | 'camera' | 'style' | 'lighting' | 'motion' | 'specs' | 'custom';
  isCustom?: boolean;
}

export type PromptFormat = 'multiline' | 'comma';

export interface PromptPreset {
  id: string;
  name: string;
  description: string;
  items: string[];
}
