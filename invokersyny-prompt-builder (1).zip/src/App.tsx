/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { PromptButton, PromptFormat, PromptPreset } from './types';
import { DEFAULT_PROMPT_BUTTONS, PROMPT_PRESETS } from './data/defaultButtons';
import { DisplayScreen } from './components/DisplayScreen';
import { KeyboardGrid } from './components/KeyboardGrid';
import { ActionBar } from './components/ActionBar';
import { CustomKeyModal } from './components/CustomKeyModal';
import { PresetsModal } from './components/PresetsModal';
import { PWAInstallButton } from './components/PWAInstallButton';
import { AndroidApkModal } from './components/AndroidApkModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { playKeySound, toggleMuteAudio, isMuted } from './utils/audio';
import { Sliders, Terminal, Sparkles, HelpCircle, Check, Info } from 'lucide-react';

const LOCAL_STORAGE_CUSTOM_KEYS = 'invokersyny_custom_keys';
const LOCAL_STORAGE_MUTED = 'invokersyny_audio_muted';

export default function App() {
  // State from Flutter _PromptGeneratorState: String currentPrompt = "(select a key)";
  const [currentPrompt, setCurrentPrompt] = useState<string>('(select a key)');
  const [format, setFormat] = useState<PromptFormat>('multiline');
  const [history, setHistory] = useState<string[]>([]);
  const [buttons, setButtons] = useState<PromptButton[]>(DEFAULT_PROMPT_BUTTONS);
  const [isCustomModalOpen, setIsCustomModalOpen] = useState<boolean>(false);
  const [isPresetsModalOpen, setIsPresetsModalOpen] = useState<boolean>(false);
  const [isAndroidApkModalOpen, setIsAndroidApkModalOpen] = useState<boolean>(false);
  const [audioMuted, setAudioMuted] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load custom keys and mute preference from localStorage
  useEffect(() => {
    try {
      const savedKeys = localStorage.getItem(LOCAL_STORAGE_CUSTOM_KEYS);
      if (savedKeys) {
        const parsed = JSON.parse(savedKeys) as PromptButton[];
        setButtons([...DEFAULT_PROMPT_BUTTONS, ...parsed]);
      }
      const savedMute = localStorage.getItem(LOCAL_STORAGE_MUTED);
      if (savedMute !== null) {
        const muted = savedMute === 'true';
        setAudioMuted(muted);
        toggleMuteAudio(muted);
      }
    } catch {
      // safe fallback
    }
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2400);
  };

  // Function from Flutter code: void addText(String text)
  const addText = useCallback((text: string) => {
    playKeySound('tap');
    setCurrentPrompt((prev) => {
      // Save prior state to history for undo capability
      setHistory((h) => [...h, prev]);

      if (prev === '(select a key)' || prev.trim() === '') {
        return text;
      } else {
        return `${prev}\n${text}`;
      }
    });
  }, []);

  // Action Button: CLEAR
  const handleClear = useCallback(() => {
    playKeySound('clear');
    setHistory((h) => [...h, currentPrompt]);
    setCurrentPrompt('(select a key)');
    showToast('Prompt cleared');
  }, [currentPrompt]);

  // Action Button: COPY PROMPT
  const handleCopy = useCallback(() => {
    playKeySound('copy');
    showToast('Copied to clipboard!');
  }, []);

  // Action Button: UNDO
  const handleUndo = useCallback(() => {
    if (history.length === 0) return;
    playKeySound('undo');
    const prev = history[history.length - 1];
    setHistory((h) => h.slice(0, -1));
    setCurrentPrompt(prev);
    showToast('Undo performed');
  }, [history]);

  // Format string for single-line vs multi-line output
  const getFormattedPrompt = useCallback(() => {
    if (currentPrompt === '(select a key)' || currentPrompt.trim() === '') {
      return '';
    }
    if (format === 'comma') {
      return currentPrompt
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean)
        .join(', ');
    }
    return currentPrompt;
  }, [currentPrompt, format]);

  // Sound toggle
  const handleToggleSound = () => {
    const nextMute = toggleMuteAudio();
    setAudioMuted(nextMute);
    try {
      localStorage.setItem(LOCAL_STORAGE_MUTED, String(nextMute));
    } catch {
      // ignore
    }
  };

  // Save new custom key
  const handleSaveCustomKey = (newBtn: Omit<PromptButton, 'id' | 'isCustom'>) => {
    const customKey: PromptButton = {
      ...newBtn,
      id: `custom-${Date.now()}`,
      isCustom: true,
    };
    const updated = [...buttons, customKey];
    setButtons(updated);

    try {
      const customOnly = updated.filter((b) => b.isCustom);
      localStorage.setItem(LOCAL_STORAGE_CUSTOM_KEYS, JSON.stringify(customOnly));
    } catch {
      // ignore
    }
    showToast(`Added [${customKey.code}] pad`);
  };

  // Delete custom key
  const handleDeleteCustomKey = (id: string) => {
    const updated = buttons.filter((b) => b.id !== id);
    setButtons(updated);
    try {
      const customOnly = updated.filter((b) => b.isCustom);
      localStorage.setItem(LOCAL_STORAGE_CUSTOM_KEYS, JSON.stringify(customOnly));
    } catch {
      // ignore
    }
    showToast('Custom pad deleted');
  };

  // Load Preset
  const handleLoadPreset = (preset: PromptPreset) => {
    playKeySound('tap');
    setHistory((h) => [...h, currentPrompt]);
    setCurrentPrompt(preset.items.join('\n'));
    showToast(`Loaded: ${preset.name}`);
  };

  // Physical keyboard hotkeys (F, T, C, S, etc.)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Do not intercept if user is typing in an input or textarea
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }

      if (e.key === 'Escape') {
        setIsCustomModalOpen(false);
        setIsPresetsModalOpen(false);
        return;
      }

      // Check if key matches button code
      const pressedCode = e.key.toUpperCase();
      const matchedBtn = buttons.find((b) => b.code.toUpperCase() === pressedCode);
      if (matchedBtn) {
        e.preventDefault();
        addText(matchedBtn.value);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [buttons, addText]);

  const activeLines =
    currentPrompt === '(select a key)' ? [] : currentPrompt.split('\n').filter(Boolean);

  const hasPrompt = currentPrompt !== '(select a key)' && currentPrompt.trim().length > 0;

  return (
    <div className="min-h-screen bg-[#0e1013] text-neutral-100 flex flex-col font-sans selection:bg-amber-500 selection:text-black">
      {/* Toast Notification Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-2.5 bg-amber-500 text-black font-mono font-bold text-xs rounded-lg shadow-xl shadow-amber-500/20 border border-amber-300 animate-in fade-in slide-in-from-top-2 duration-200">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Flutter AppBar: AppBar(title: Text("INVOKERSYNY PROMPT BUILDER")) */}
      <header className="sticky top-0 z-40 bg-[#16181d] border-b border-[#252830] shadow-md">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black shadow-md shadow-amber-500/20">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-extrabold tracking-wider font-mono text-white uppercase flex items-center gap-2">
                <span>INVOKERSYNY PROMPT BUILDER</span>
                <span className="hidden md:inline-block text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40">
                  MPC KEYBOARD
                </span>
              </h1>
              <p className="text-[11px] text-neutral-400 font-mono hidden sm:block">
                Tactile prompt sequencer for cinematic AI video generation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <PWAInstallButton onOpenAndroidModal={() => setIsAndroidApkModalOpen(true)} />
            <button
              type="button"
              onClick={() => setIsPresetsModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#21242b] hover:bg-[#2b303a] text-neutral-200 border border-neutral-700 text-xs font-mono font-semibold transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">PRESETS</span>
            </button>
            <button
              type="button"
              onClick={() => setIsCustomModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black text-xs font-mono font-bold transition-colors shadow-sm"
            >
              <span>+ KEY</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main App Body */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-3 sm:p-5 flex flex-col gap-5">
        {/* 1. DISPLAY SCREEN (Signature Beige LCD screen: Color(0xFFE5D1B0)) */}
        <section aria-label="Prompt Output Screen">
          <DisplayScreen
            promptText={currentPrompt}
            onPromptChange={setCurrentPrompt}
            onClear={handleClear}
            onCopy={handleCopy}
            onUndo={handleUndo}
            format={format}
            onFormatChange={setFormat}
            historyCount={history.length}
          />
        </section>

        {/* 2. SHORT CODE BUTTONS (The Keyboard) */}
        <section aria-label="Short Code Keyboard Grid" className="flex-1">
          <KeyboardGrid
            buttons={buttons}
            onButtonPress={(btn) => addText(btn.value)}
            onDeleteCustom={handleDeleteCustomKey}
            onOpenAddCustom={() => setIsCustomModalOpen(true)}
            activePromptLines={activeLines}
          />
        </section>

        {/* 3. ACTION BUTTONS: CLEAR & COPY PROMPT */}
        <section aria-label="Action Controls" className="sticky bottom-3 z-30">
          <ActionBar
            onClear={handleClear}
            onCopy={handleCopy}
            onOpenPresets={() => setIsPresetsModalOpen(true)}
            isMuted={audioMuted}
            onToggleSound={handleToggleSound}
            hasPrompt={hasPrompt}
            formattedText={getFormattedPrompt()}
          />
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1d2026] bg-[#0c0e11] py-3 text-center text-xs font-mono text-neutral-500">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>INVOKERSYNY PROMPT BUILDER &bull; DARK WORKSTATION</span>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsAndroidApkModalOpen(true)}
              className="text-amber-400/90 hover:text-amber-300 underline underline-offset-4 cursor-pointer"
            >
              Android APK Build Guide &amp; WebAPK
            </button>
            <span>&bull;</span>
            <span>Keys: F, T, C, S</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <CustomKeyModal
        isOpen={isCustomModalOpen}
        onClose={() => setIsCustomModalOpen(false)}
        onSave={handleSaveCustomKey}
      />

      <PresetsModal
        isOpen={isPresetsModalOpen}
        onClose={() => setIsPresetsModalOpen(false)}
        presets={PROMPT_PRESETS}
        onLoadPreset={handleLoadPreset}
      />

      <AndroidApkModal
        isOpen={isAndroidApkModalOpen}
        onClose={() => setIsAndroidApkModalOpen(false)}
      />

      <OfflineIndicator />
    </div>
  );
}
