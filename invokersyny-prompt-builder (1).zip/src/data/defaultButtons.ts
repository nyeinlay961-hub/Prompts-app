import { PromptButton, PromptPreset } from '../types';

export const DEFAULT_PROMPT_BUTTONS: PromptButton[] = [
  // 1. Original 4 buttons from Flutter code
  {
    id: 'btn-f',
    code: 'F',
    label: 'Clip',
    value: 'Clip: First Clip',
    category: 'clip',
  },
  {
    id: 'btn-t',
    code: 'T',
    label: 'Time',
    value: 'Time: 00:00-00:05',
    category: 'clip',
  },
  {
    id: 'btn-c',
    code: 'C',
    label: 'Camera',
    value: "Camera: Bird's Eye View",
    category: 'camera',
  },
  {
    id: 'btn-s',
    code: 'S',
    label: 'Style',
    value: 'Style: Cinematic Anime',
    category: 'style',
  },

  // Expanded Buttons: Camera & Shots
  {
    id: 'btn-cu',
    code: 'CU',
    label: 'Close-Up',
    value: 'Camera: Extreme Close-Up Macro',
    category: 'camera',
  },
  {
    id: 'btn-fp',
    code: 'FP',
    label: 'FPV Drone',
    value: 'Camera: Fast FPV Drone Flythrough',
    category: 'camera',
  },
  {
    id: 'btn-do',
    code: 'DO',
    label: 'Dolly Zoom',
    value: 'Camera: Hitchcock Vertigo Dolly Zoom',
    category: 'camera',
  },
  {
    id: 'btn-or',
    code: 'OR',
    label: 'Orbit 360',
    value: 'Camera: 360° Smooth Orbiting Pan',
    category: 'camera',
  },
  {
    id: 'btn-la',
    code: 'LA',
    label: 'Low Angle',
    value: 'Camera: Dynamic Dutch Low Angle',
    category: 'camera',
  },
  {
    id: 'btn-an',
    code: 'AN',
    label: 'Anamorphic',
    value: 'Lens: 35mm Vintage Anamorphic F/1.4',
    category: 'camera',
  },

  // Expanded Buttons: Styles & Aesthetics
  {
    id: 'btn-pr',
    code: 'PR',
    label: 'Photoreal',
    value: 'Style: 8K Hyper-Realistic Film Still',
    category: 'style',
  },
  {
    id: 'btn-cy',
    code: 'CY',
    label: 'Cyberpunk',
    value: 'Style: Neo-Tokyo Dystopian Cyberpunk',
    category: 'style',
  },
  {
    id: 'btn-no',
    code: 'NO',
    label: 'Film Noir',
    value: 'Style: High-Contrast 1950s Moody Noir',
    category: 'style',
  },
  {
    id: 'btn-16m',
    code: '16M',
    label: '16mm Film',
    value: 'Style: Authentic 16mm Grain Kodak 500T',
    category: 'style',
  },
  {
    id: 'btn-3d',
    code: '3D',
    label: '3D Octane',
    value: 'Style: Stylized 3D Octane Clay Render',
    category: 'style',
  },

  // Expanded Buttons: Lighting & Atmosphere
  {
    id: 'btn-gh',
    code: 'GH',
    label: 'Golden Hr',
    value: 'Lighting: Golden Hour Warm Sunflare',
    category: 'lighting',
  },
  {
    id: 'btn-ne',
    code: 'NE',
    label: 'Neon Rim',
    value: 'Lighting: Neon Magenta Rim Lighting',
    category: 'lighting',
  },
  {
    id: 'btn-vo',
    code: 'VO',
    label: 'Volumetric',
    value: 'Lighting: Heavy Volumetric God Rays & Mist',
    category: 'lighting',
  },
  {
    id: 'btn-mo',
    code: 'MO',
    label: 'Moonlight',
    value: 'Lighting: Cold Blue Ethereal Moonlight',
    category: 'lighting',
  },

  // Expanded Buttons: Motion & Dynamics
  {
    id: 'btn-sm',
    code: 'SM',
    label: 'Slow-Mo',
    value: 'Motion: 120fps Bullet-Time Hyper Slow-Mo',
    category: 'motion',
  },
  {
    id: 'btn-fa',
    code: 'FA',
    label: 'Fast Action',
    value: 'Motion: Kinetic High-Octane Action Blur',
    category: 'motion',
  },
  {
    id: 'btn-tl',
    code: 'TL',
    label: 'Timelapse',
    value: 'Motion: Day-to-Night Hyperlapse Transition',
    category: 'motion',
  },

  // Expanded Buttons: Sequence & Specs
  {
    id: 'btn-sc',
    code: 'SC',
    label: 'Second Clip',
    value: 'Clip: Second Clip Transition',
    category: 'clip',
  },
  {
    id: 'btn-ot',
    code: 'OT',
    label: 'Outro',
    value: 'Clip: Final Hero Freeze Frame Outro',
    category: 'clip',
  },
  {
    id: 'btn-ar',
    code: 'AR',
    label: '16:9 Aspect',
    value: 'Aspect Ratio: 16:9 Widescreen',
    category: 'specs',
  },
  {
    id: 'btn-4k',
    code: '4K',
    label: '4K Master',
    value: 'Quality: Mastered in 4K UHD Pro-Res',
    category: 'specs',
  },
  {
    id: 'btn-fps',
    code: '60',
    label: '60 FPS',
    value: 'Pacing: 60 FPS Ultra-Smooth Temporal Coherence',
    category: 'specs',
  },
  {
    id: 'btn-neg',
    code: 'CL',
    label: 'Clean Neg',
    value: 'Negative: no distortion, no blurry artifacts, no watermark',
    category: 'specs',
  },
];

export const PROMPT_PRESETS: PromptPreset[] = [
  {
    id: 'preset-anime',
    name: 'Cinematic Anime Intro',
    description: 'Dynamic anime opening scene with fast camera motion',
    items: [
      'Clip: First Clip',
      'Time: 00:00-00:05',
      "Camera: Bird's Eye View",
      'Style: Cinematic Anime',
      'Lighting: Golden Hour Warm Sunflare',
      'Motion: Kinetic High-Octane Action Blur',
      'Aspect Ratio: 16:9 Widescreen',
    ],
  },
  {
    id: 'preset-cyberpunk',
    name: 'Cyberpunk Drone Chase',
    description: 'Neon drenched rainy city with FPV drone tracking',
    items: [
      'Clip: First Clip',
      'Time: 00:00-00:05',
      'Camera: Fast FPV Drone Flythrough',
      'Style: Neo-Tokyo Dystopian Cyberpunk',
      'Lighting: Neon Magenta Rim Lighting',
      'Quality: Mastered in 4K UHD Pro-Res',
      'Aspect Ratio: 16:9 Widescreen',
    ],
  },
  {
    id: 'preset-noir',
    name: 'Moody Noir Detective',
    description: 'Classic monochrome high-contrast film scene',
    items: [
      'Clip: First Clip',
      'Time: 00:00-00:08',
      'Camera: Dynamic Dutch Low Angle',
      'Style: High-Contrast 1950s Moody Noir',
      'Lighting: Heavy Volumetric God Rays & Mist',
      'Style: Authentic 16mm Grain Kodak 500T',
    ],
  },
  {
    id: 'preset-macro',
    name: '8K Nature Macro',
    description: 'Slow motion extreme close up with soft lighting',
    items: [
      'Clip: First Clip',
      'Time: 00:00-00:04',
      'Camera: Extreme Close-Up Macro',
      'Lens: 35mm Vintage Anamorphic F/1.4',
      'Style: 8K Hyper-Realistic Film Still',
      'Motion: 120fps Bullet-Time Hyper Slow-Mo',
      'Lighting: Cold Blue Ethereal Moonlight',
    ],
  },
];
